"""Generate synthetic datasets for the dashboard."""
import numpy as np, pandas as pd
rng = np.random.default_rng(42)
regions = ["North", "South", "East", "West"]
cats = ["Software", "Hardware", "Services", "Subscriptions"]

# 1. sales (daily, per region/category)
dates = pd.date_range("2024-01-01", "2024-12-31")
rows = []
for d in dates:
    for r in regions:
        for c in cats:
            orders = rng.integers(5, 40)
            avg = rng.normal(120, 25) * (1 + 0.2 * (c == "Hardware"))
            rows.append([d, r, c, orders, round(orders * max(avg, 20), 2)])
sales = pd.DataFrame(rows, columns=["date", "region", "category", "orders", "revenue"])
sales.to_csv("data/sales.csv", index=False)

# 2. users (monthly active users per region)
months = pd.period_range("2024-01", "2024-12", freq="M").to_timestamp()
users = pd.DataFrame([[m, r, int(5000 + i * 220 + rng.integers(-300, 300) + j * 400)]
                      for i, m in enumerate(months) for j, r in enumerate(regions)],
                     columns=["month", "region", "active_users"])
users.to_csv("data/users.csv", index=False)

# 3. churn (monthly churn % per region)
churn = pd.DataFrame([[m, r, round(rng.uniform(2.0, 6.5), 2)]
                      for m in months for r in regions],
                     columns=["month", "region", "churn_pct"])
churn.to_csv("data/churn.csv", index=False)

# 4. tickets (support / purchase ticket sizes)
tickets = pd.DataFrame({
    "date": rng.choice(dates, 3000),
    "region": rng.choice(regions, 3000),
    "category": rng.choice(cats, 3000),
    "ticket_size": rng.gamma(4, 30, 3000).round(2)})
tickets.to_csv("data/tickets.csv", index=False)
print("Datasets created in /data")

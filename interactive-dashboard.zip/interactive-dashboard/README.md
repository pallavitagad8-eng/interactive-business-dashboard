# Interactive Business Dashboard (Streamlit + Plotly)

Interactive BI dashboard with KPI summary cards, dynamic filters and responsive charts.

## Features
- **KPI cards:** Total Revenue, Active Users, Churn %, Avg Ticket Size
- **Filters (slicers):** Date Range, Region, Category
- **Charts:** Monthly revenue trend, revenue by category, revenue share by region, active users by region, churn trend, ticket size distribution
- Responsive layout (`use_container_width`, column grid)

## Run locally
```bash
pip install -r requirements.txt
python generate_data.py   # optional: regenerate synthetic data
streamlit run app.py
```

## Project structure
```
app.py              # dashboard
generate_data.py    # synthetic dataset generator
data/               # sales.csv, users.csv, churn.csv, tickets.csv
requirements.txt
```

## Live demo
<paste your Streamlit Community Cloud URL here>

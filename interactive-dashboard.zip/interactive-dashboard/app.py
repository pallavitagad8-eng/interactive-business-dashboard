"""Interactive Business Dashboard - Streamlit + Plotly."""
import pandas as pd
import plotly.express as px
import streamlit as st

st.set_page_config(page_title="Business Dashboard", page_icon="📊", layout="wide")

@st.cache_data
def load():
    s = pd.read_csv("data/sales.csv", parse_dates=["date"])
    u = pd.read_csv("data/users.csv", parse_dates=["month"])
    c = pd.read_csv("data/churn.csv", parse_dates=["month"])
    t = pd.read_csv("data/tickets.csv", parse_dates=["date"])
    return s, u, c, t

sales, users, churn, tickets = load()

# ---------- Sidebar: dynamic filters (slicers) ----------
st.sidebar.header("Filters")
dmin, dmax = sales["date"].min().date(), sales["date"].max().date()
date_range = st.sidebar.date_input("Date Range", (dmin, dmax), min_value=dmin, max_value=dmax)
if len(date_range) != 2:
    st.info("Select both start and end date.")
    st.stop()
start, end = map(pd.Timestamp, date_range)
regions = st.sidebar.multiselect("Region", sorted(sales["region"].unique()), default=sorted(sales["region"].unique()))
cats = st.sidebar.multiselect("Category", sorted(sales["category"].unique()), default=sorted(sales["category"].unique()))

def f(df, col="date", cat=True):
    m = df[col].between(start, end) & df["region"].isin(regions)
    if cat and "category" in df:
        m &= df["category"].isin(cats)
    return df[m]

s, u, c, t = f(sales), f(users, "month", False), f(churn, "month", False), f(tickets)
if s.empty:
    st.warning("No data for the selected filters.")
    st.stop()

# ---------- KPI cards ----------
st.title("📊 Business Performance Dashboard")
k1, k2, k3, k4 = st.columns(4)
k1.metric("Total Revenue", f"${s['revenue'].sum():,.0f}")
k2.metric("Active Users", f"{int(u.groupby('month')['active_users'].sum().iloc[-1]):,}" if not u.empty else "-")
k3.metric("Churn %", f"{c['churn_pct'].mean():.2f}%" if not c.empty else "-")
k4.metric("Avg Ticket Size", f"${t['ticket_size'].mean():,.2f}" if not t.empty else "-")
st.divider()

# ---------- Charts (responsive via use_container_width) ----------
r1c1, r1c2 = st.columns(2)
rev_m = s.set_index("date").resample("MS")["revenue"].sum().reset_index()
r1c1.plotly_chart(px.line(rev_m, x="date", y="revenue", markers=True, title="Monthly Revenue Trend"), use_container_width=True)
r1c2.plotly_chart(px.bar(s.groupby("category", as_index=False)["revenue"].sum(), x="category", y="revenue",
                         color="category", title="Revenue by Category"), use_container_width=True)

r2c1, r2c2 = st.columns(2)
r2c1.plotly_chart(px.pie(s.groupby("region", as_index=False)["revenue"].sum(), names="region", values="revenue",
                         hole=0.45, title="Revenue Share by Region"), use_container_width=True)
if not u.empty:
    r2c2.plotly_chart(px.area(u.groupby(["month", "region"], as_index=False)["active_users"].sum(),
                              x="month", y="active_users", color="region", title="Active Users by Region"),
                      use_container_width=True)

r3c1, r3c2 = st.columns(2)
if not c.empty:
    r3c1.plotly_chart(px.line(c.groupby("month", as_index=False)["churn_pct"].mean(), x="month", y="churn_pct",
                              title="Average Churn %"), use_container_width=True)
if not t.empty:
    r3c2.plotly_chart(px.histogram(t, x="ticket_size", nbins=30, title="Ticket Size Distribution"),
                      use_container_width=True)

with st.expander("View filtered data"):
    st.dataframe(s.head(500), use_container_width=True)
